const express = require('express');
const morgan = require('morgan');
var parser = require('body-parser');
var ldap = require('ldapjs');

var router = express.Router();

const app = express();
app.use(morgan('dev'));

app.use(parser.urlencoded({ extended: false }));

app.set('appName', 'Servidor para Login');
app.set('views', __dirname + '/views');

app.get('/',(req,res) => {
    res.render('login.ejs');
});

app.get('/veri',(req,res) => {
    console.log("andresitoooo: "+username);
    res.render('verificacion.ejs');
});

app.post('/veri',(req,res) => {
//usuario
var username = req.body.username;
//contraseña
var password = req.body.password;
// creacion de conexion con OpenLDAP
var client = ldap.createClient({
    url: 'ldap://127.0.0.1:389'
});
//Filtro para encontrar el dn,sn,cn,'userPassword' por medio del mail
var opts = {
  filter: '(mail= ' + username+ ')',
  scope: 'sub',
  paged: true,
  sizeLimit: 200,
  attributes: ['dn', 'sn', 'cn', 'userPassword']  
};
//Busqueda del dn 
client.search('dc=example,dc=com', opts, function(err, res) {
  res.on('searchEntry', function(entry) {
    //Almacenamiento del dn, para tener todo el objeto json: entry.object sin el .dn
    var dnObtained = entry.object.dn;
    //Autentificación en base al dn obtenido y password isertado por usuario 
    client.bind(dnObtained,password , function(err, res) {
        if(err){
            console.log('ERROR! USUARIO O CONRASEñA INCORRECTO');
        }else {
            console.log('INGRESO CORRECTO');
        } 
    });
  });
});
    res.render('verificacion.ejs');
});


app.listen(5013, function(){
    console.log('servidor funcionando!');
});



